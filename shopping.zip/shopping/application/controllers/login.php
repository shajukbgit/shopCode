<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
	parent::__construct();
	$this->load->model('login_model');
	$this->load->helper('url');
	$this->load->library('session');
	} 
	 
	public function index()
	{
		$this->load->view('login');
	}
	
	public function check_login()
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		$login_status = $this->login_model->check_login($username,$password);
		if(!empty($login_status))
		{
		$this->session->set_flashdata('flash_message', 'Welcome Admin !' );
		redirect('dashboard');
		} else {
		$this->session->set_flashdata('flash_message', 'Invalid Login !' );
		redirect('login'); 
		}

		$this->load->view('login');
	}
}

