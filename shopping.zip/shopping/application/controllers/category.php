<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller {

	public function __construct()
	{
	parent::__construct();
	$this->load->model('category_model');
	$this->load->helper('url');
	$this->load->helper('form');
	$this->load->library('session');
	} 
	 
	public function category_list()
	{
		$data['category_all'] = $this->category_model->get_all_categories();
		$this->load->view('category_list',$data);
	}

	public function add()
	{
		$this->load->view('category_add');
	}
		 
	public function save()
	{
		$form_data['name'] = $_POST['name'];
		$this->category_model->insert_category('category',$form_data);
		$this->session->set_flashdata('flash_message','Category Inserted !');
		redirect('category/category_list');
	}	
	
	public function edit()
	{   
		$id = $this->uri->segment(3);
		$data['row'] = $this->category_model->edit_mode($id);
		$this->load->view('category_edit',$data);
	}	
	
	public function update()
	{
		$data['name'] = $_POST['name'];
		$id = $_POST['id'];
		$this->category_model->update_category($id,$data);
		$this->session->set_flashdata('flash_message','Category Updated !');
		redirect('category/category_list');
	}	
	
	public function delete()
	{
	    $id = $this->uri->segment(3);
	    $this->category_model->delete_category($id);
		$this->session->set_flashdata('flash_message','Category Deleted !');
		redirect('category/category_list');
	}
}

