<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model{

	public function __construct()
	{
	 $this->load->database();
	 $this->postTable = 'category';
	} 
	
	public function get_all_categories()
	{
	 $this->db->select('*');
	 $this->db->from('category');
	 $query = $this->db->get();
	 return $query->result_array();
	}
	
	public function insert_category($table,$data)
	{
	$this->db->insert($table,$data);
    //echo $this->db->last_query();
    //exit;
	return $this->db->insert_id();
	}
	
	public function edit_mode($id)
	{
	  $this->db->select('*');
	  $this->db->from('category');
	  $this->db->where('id',$id);
	  $query = $this->db->get();
	  return $query->result_array();
	}
	
	public function update_category($id,$data)
	{
	  $this->db->where('id',$id);
	  $query = $this->db->update('category',$data);
	  return;
	}

	public function delete_category($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('category');
		return;
	}
}

