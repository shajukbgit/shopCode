<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model{

	public function __construct()
	{
	 $this->load->database();
	 $this->postTable = 'category';
	} 

	public function delete_category($id)
	{
		$this->db->where('id',$id);
		$this->db->from('category');
		return 
		
	}
}

