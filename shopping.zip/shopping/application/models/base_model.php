<?php
class Base_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
	function insertdata($tbl,$formData){
        $this->db->insert($tbl, $formData);
        return $this->db->insert_id();
	}
    
    function deletedata($tbl,$formData){
	    $this->db->delete($tbl, $formData);
	}
    
    function updatedata($tbl, $where, $data){
        $this->db->where($where); 
        $query = $this->db->update($tbl, $data); 
        return $query; 
	}
    
    function selectall($tbl){
        $this->db->select('*'); 
        $this->db->from($tbl);
        $query = $this->db->get(); //    echo $this->db->last_query();
        return $query->result_array(); 
	}
    
    function selectdata($tbl,$where){
        $this->db->select('*'); 
        $this->db->from($tbl);
        $this->db->where($where); 
        $query = $this->db->get();     //echo $this->db->last_query(); exit();
        return $query; 
	}
    function select_or_data($tbl,$where, $orwhere){
        $this->db->select('*'); 
        $this->db->from($tbl);
        $this->db->where($where); 
        $this->db->or_where($orwhere);
        $query = $this->db->get(); //    echo $this->db->last_query();
        return $query; 
	}
    
    public function record_count($tbl)
	{
     return $this->db->count_all($tbl);
    }
	
	public function selectall_menu($val)
	{
	$this->db->select('*'); 
	$this->db->from('menu');
	$this->db->where('MenuName', $val);
	$this->db->where('Status', '1');
	$query = $this->db->get();     echo $this->db->last_query();
	return $query->row();
    //return $query->row('RightsID');
	}
	

       public function CheckDataExist($table_id,$table,$dataArray)
	{
	   $this->db->select($table_id); 
        $this->db->from($table); 
	    $this->db->where($dataArray);
        $query = $this->db->get(); 

		return $query->row($table_id);
		//return $query;
	}
	
	
		public function selectall_submenu($val)
	{
	$this->db->select('*'); 
	$this->db->from('submenu');
	$this->db->where('SubMenuName', $val);
	$this->db->where('Status', '1');
	$query = $this->db->get();    // echo $this->db->last_query();
	return $query->row();
    //return $query->row('RightsID');
	}
	
  public function selectOneRecord($tbl,$primeryField,$id){

	    $this->db->select('*'); 
        $this->db->from($tbl);
        $this->db->where($primeryField,$id); 
	    $query = $this->db->get();
	    return $query->result_array();
	}

  public function deleteRecordById($tbl,$primeryField,$id){
	 	$this->db->where($primeryField, $id);
		$this->db->delete($tbl);  
  }
  
		function getRecordNameCount($tbl,$FieldName,$primeryField,$Id,$name)
		{
		$this->db->select('*');
		$this->db->where(array($FieldName => $name,$primeryField.' !=' => $Id));
		$query = $this->db->get($tbl);
		//echo $this->db->last_query();		exit;

		return $num = $query->num_rows();
	    }
		
	  function UpdateTable($tbl,$primeryField,$Id,$frmData)
	  {
		//  print_r($frmData); die();
	  $this->db->where($primeryField,$Id);   										
      $query = $this->db->update($tbl, $frmData); 
	 // echo $this->db->last_query();exit;
	  return $query; 
	  }
	  
	  function CurrentPasswordCheck($password)
	  {
		$this->db->select('*');
		$this->db->where(array('UserName' => $this->session->userdata('name'),'Password' => md5($password)));
		$query = $this->db->get('login');
		//echo $this->db->last_query();		exit;

		return $num = $query->num_rows();  
	  }
	  
	  function UpdateNewPassword($NewPassword)
	  {
		$this->db->where(array('UserName' => $this->session->userdata('name'))); 
		$query = $this->db->update('login', array('Password' => md5($NewPassword))); 
		//echo $this->db->last_query(); exit();
	  	return $query; 
	  }
  
  	function nextcount($table)
	{
			$this->db->select_max('sortorder');
			$result = $this->db->get($table)->row();  
			$next=($result->sortorder)+1; return $next;
	}
  
}