<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model{

	public function __construct()
	{
	 $this->load->database();
	 $this->postTable = 'login';
	} 

	public function check_login($username,$password)
	{
		$this->db->select('*');
		$this->db->from('login');
		$this->db->where('username',$username);
		$this->db->where('password',md5($password));
		
		$query = $this->db->get();
		//echo $this->db->last_query();
		//exit;
		return $query->result_array();
		
	}
}

